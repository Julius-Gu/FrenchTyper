FrenchTyper by Julius Guthunz

This is a small and lightweight programm allowing users to copy all of the special french symbols to
the clipboard. Then you can paste it into any word processor / text editor that supports unicode 
(that is pretty much anyone out there) with Ctrl+C. Just double click the "FrenchTyperWin64" link to
run it.

It was written in plain C with GTK+ 3.0. Feel free to distribute it under the terms of the GNU
General Public License 3.0 or higher.

the source code as well as further instructions are available at
https://github.com/Julius-Gu/FrenchTyper

Best Regards, Julius