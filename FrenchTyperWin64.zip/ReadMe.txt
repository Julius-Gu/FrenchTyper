FrenchTyper by Julius Guthunz

This is a small and lightweight programm allowing users to copy all of the special french symbols to
the clipboard. Then you can paste it into any word processor / text editor that supports unicode 
(that is pretty much anyone out there) with Ctrl+C. 

It was written in plain C with GTK+ 3.0. Feel free to distribute it under the terms of the GNU
General Public License 3.0 or higher.

the source code is available at
https://github.com/Julius-Gu/FrenchTyper

Dependencies are libgtk-3-0
(sudo apt install libgtk-3-0)
The C File can be compiled on Linux with
cd [Directory of the File]
gcc FrenchTyper.c -o FrenchTyper `pkg-config --libs --cflags gtk+-3.0`

Best Regards, Julius

P.s. I'm litterally writing this at 1 am so please let me know of any typos, etc. :)